// import { createClient } from '@supabase/supabase-js';


// const supabase = createClient(
//   process.env.NEXT_PUBLIC_SUPABASE_URL,
//   process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

// );

// export default supabase;



import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://fswlcclmmwwhzkqfbmhc.supabase.co';
const supabaseAnonKey  ='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZzd2xjY2xtbXd3aHprcWZibWhjIiwicm9sZSI6ImFub24iLCJpYXQiOjE2OTcxMjg2MDcsImV4cCI6MjAxMjcwNDYwN30.UFaFkR2RtuorvxlwCsCNhIMeh2SK8ArNT2VH4MlNvrA';

 const supabase = createClient(supabaseUrl, supabaseAnonKey);
 export default supabase;