import React from 'react'
import { Create_acc_Button, Signup_Button } from '../components/Buttons'


function Login0() {
  return (
    <div>
        <h1 className="w-full py-[12px] px-[16px] text-center text-lg">100X</h1>
        <main>
            <h3 className="text-3xl bg-blue-500">Hapenning now</h3>
            <p>Join today.</p>
            <Create_acc_Button >Create account</Create_acc_Button>
            <div className="">
                <p></p>
                <p>or</p>
                <p></p>
            </div>
            <p>Already have an account?</p>
        <Signup_Button >Sign in</Signup_Button></main>
    </div>
  )
}

export default Login0