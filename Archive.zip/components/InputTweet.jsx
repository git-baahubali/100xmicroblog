export function InputTweet(){
    return(
        <div className="box-border bg-black max-w-[512px] h-[355px] px-[15px] py-[10px] border border-black rounded-[16px]">

        </div>
        )
}


export function SignUp(){
    return(
        <div className="flex justify-start  box-border bg-black  px-[15px] py-[10px]  border rounded-[16px]">
           <img src="images/close.svg" alt=""  className=""/>
            <header className="border px-[12px] py-[16px]"> Header</header>
            

        </div>
        )
}

